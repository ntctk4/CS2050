/*
 *Nathaniel Callahan
 *ntctk4
 *lab 5
 *labe code: FLY
 *
 */
#include<stdio.h>
#include"minesweeper.h"
#include<stdlib.h>

int main(int argc, char* argv[])
{
	int guess;
	int row;//what user puts in as row
	int col;// what user puts in as col
	PositionType board[BoardSize][BoardSize];// array game board for user

	if (argc != 2)
	{
		printf("incorrect number of arguments");
			return -1;
	}


	setBoard(board, atoi(argv[1]));

	printf("\n\nEnter a row and col:");
	scanf("%d %d", &row, &col); 

	

	guess = processGuess(board, row, col);

	while(guess == -1 || guess == 0 || guess == 1)
	{
	
		
		displayBoard(board);

		printf("Enter a row and col:");
		scanf("%d %d", &row, &col);
		
		guess = processGuess(board, row, col);

	}

	if(guess == 2)
	{
		displayBoard(board);
		printf("\nGame over, you lose");

	}

	return 0;
}
		




