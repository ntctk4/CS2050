//ntctk4
#include<stdio.h>
#include"minesweeper.h"
#include<time.h>

void setBoard(PositionType board[BoardSize][BoardSize], int numMines)// This function fills the array with bombs and covered spaces
{

	int i;
	int j;
	int mine;

	srand(time(NULL));

	for(i=0; i<BoardSize; i++)
	{
		for(j=0; j<BoardSize; j++)
		{
			board[i][j] = covered;
		}
	}

	for(mine=0; mine < numMines; mine++)
	{
		i = rand()%10;
		j = rand()%10;

		board[i][j] = coveredBomb;
	}
}

void displayBoard(PositionType board[BoardSize][BoardSize])//this displays the game array to the user
{

	int i;
	int j;


	printf("1 2 3 4 5 6 7 8 9 10\n");


	for(i=0; i<BoardSize; i++)
	{
	

		printf("\n");

		for(j=0; j<BoardSize; j++)
		{



			if( board[i][j] == covered || board[i][j] == coveredBomb)
			{
				printf("# ");
			}
		
			else if(board[i][j] == uncovered)
			{
				printf("  ");
			}

			else
			{
				printf("@ ");
			}
		}
	}
}

int processGuess(PositionType board[BoardSize][BoardSize], int row, int col)//this ckecks the array spot to see what is in it and error checks user
{
	if(row > BoardSize || col > BoardSize)
	{
		printf("Invalid position");
		return -1;
	}

	else if(board[row-1][col-1] == uncovered)
	{
		printf("That position has already been picked");
		return 0;
	}

	else if(board[row-1][col-1] == covered)
	{
		board[row-1][col-1] = uncovered;
		return 1;
	}

	else if(board[row-1][col-1] == coveredBomb)
	{
		board[row][col] = uncoveredBomb;
		return 2;
	}
}
